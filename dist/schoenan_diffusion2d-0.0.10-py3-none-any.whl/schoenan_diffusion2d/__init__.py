from .diffusion2d import solve
from .output import create_plot, output_plots