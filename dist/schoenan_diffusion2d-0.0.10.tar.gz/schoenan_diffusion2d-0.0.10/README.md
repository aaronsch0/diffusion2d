# diffusion2d

## Description

This small Python project solves the two-dimensional diffusion (heat) equation on a square plate using a finite-difference scheme.

Key points about the model and the code:

- The computational domain is a square plate of size `w x h` (units in mm in the example).
- The plate is initialized at a base temperature `T_cold` and contains a circular region in the centre at a higher temperature `T_hot`.
- The time integration is performed with an explicit forward-difference scheme, while spatial derivatives are approximated with central differences.
- The code computes a stable timestep `dt` for the explicit scheme from the grid spacings `dx`, `dy` and the thermal diffusivity `D`.
- Parameters such as `dx`, `dy`, `D` and the number of timesteps can be changed by the user.

Code layout and functions (current repository state):

- `diffusion2d/diffusion2d/diffusion2d.py` – main solver module. It defines `solve(w,h,dx,dy,D,T_cold,T_hot)` and also can be executed as a script (it calls `solve(...)` in the `if __name__ == "__main__"` guard).
- `diffusion2d/diffusion2d/output.py` – plotting helper functions that the solver uses to create and finalize subplots.

Output:

The script produces four snapshots of the temperature distribution at selected timesteps and arranges them in a single figure with a shared colorbar so the diffusion of heat is easy to observe.

## Installing the package

To run the example you only need Python (>= 3.6) and the required libraries (NumPy and Matplotlib).

Recommended steps (macOS / Linux / WSL):

1. Check Python version:

```bash
python3 --version
```

2. If your Python is older than 3.6, update it (for example via Homebrew on macOS):

```bash
brew install python
```

3. (Optional) Create and activate a virtual environment:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

5. Install dependencies:

```bash
python3 -m pip install numpy matplotlib
```

6. Install the package:

```bash
pip install -i https://test.pypi.org/simple/ schoenan-diffusion2d==0.0.10
```

## Running this package

Run the script from the repository root. Note: in this repository the solver script is placed in the `diffusion2d/` subfolder, so run:

```bash
python3 diffusion2d/diffusion2d/diffusion2d.py
```

Alternatively you can import and call the solver from Python:

```python
from diffusion2d.diffusion2d import solve
# call with default example parameters
solve(10., 10., 0.1, 0.1, 4., 300, 700)
```

What to expect:

- The script prints the computed timestep `dt`.
- A plotting window opens showing four subplots (temperature fields at different times) and a shared colorbar.

Notes about plotting helpers:

- `diffusion2d/diffusion2d/output.py` provides two convenience functions used by the solver:
	- `create_plot(fig_counter, T_cold, T_hot, dt, u, n, fig)` – creates and configures a single subplot for time index `n` and returns the `AxesImage` (`im`).
	- `output_plots(im, fig)` – finalizes the figure (adds shared colorbar and shows the plot window).

Tips:

- Try changing `dx`, `dy` and `D` inside `diffusion2d.py` and observe how `dt` and runtime change. Smaller `dx`/`dy` increase the grid size and therefore the computation time.
- The script computes `dt` to satisfy the stability condition for the explicit scheme; if you change parameters, check `dt` to ensure stability.

## Citing

If you reuse this example in teaching or publications, please cite the book chapter and the scipython example page:

- "Learning Scientific Programming with Python", chapter 7 (two-dimensional diffusion example).
- scipython.com: The two-dimensional diffusion equation (https://scipython.com/book/chapter-7-matplotlib/examples/the-two-dimensional-diffusion-equation/)
